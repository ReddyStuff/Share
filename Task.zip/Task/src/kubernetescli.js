"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("azure-pipelines-task-lib/task");
const fs = require("fs");
const basecommand_1 = require("./basecommand");
const EXIT_CODE_SUCCESS = 0;
const EXIT_CODE_FAILURE = 2;
class kubernetescli extends basecommand_1.default {
    constructor(kubeconfigPath) {
        super(true);
        this.kubeconfigPath = kubeconfigPath;
    }
    getTool() {
        return "kubectl";
    }
    login() {
        process.env["KUBECONFIG"] = this.kubeconfigPath;
    }
    logout() {
        if (this.kubeconfigPath != null && fs.existsSync(this.kubeconfigPath)) {
            delete process.env["KUBECONFIG"];
            fs.unlinkSync(this.kubeconfigPath);
        }
    }
    setKubeConfigEnvVariable() {
        if (this.kubeconfigPath && fs.existsSync(this.kubeconfigPath)) {
            tl.setVariable("KUBECONFIG", this.kubeconfigPath);
            tl.setVariable('helmExitCode', EXIT_CODE_SUCCESS.toString());
        }
        else {
            tl.error(tl.loc('KubernetesServiceConnectionNotFound'));
            tl.setVariable('helmExitCode', EXIT_CODE_FAILURE.toString());
            throw new Error(tl.loc('KubernetesServiceConnectionNotFound'));
        }
    }
    unsetKubeConfigEnvVariable() {
        var kubeConfigPath = tl.getVariable("KUBECONFIG");
        if (kubeConfigPath) {
            tl.setVariable("KUBECONFIG", "");
        }
        tl.setVariable('helmExitCode', EXIT_CODE_SUCCESS.toString());
    }
    getAllPods() {
        var command = this.createCommand();
        command.arg('get');
        command.arg('pods');
        command.arg(['-o', 'json']);
        return this.execCommandSync(command);
    }
    getClusterInfo() {
        const command = this.createCommand();
        command.arg('cluster-info');
        return this.execCommandSync(command);
    }
}
exports.default = kubernetescli;
