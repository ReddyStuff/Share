"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("azure-pipelines-task-lib/task");
const tlssetting_1 = require("./../tlssetting");
function addArguments(helmCli) {
    var namespace = tl.getInput("namespace", false);
    var argumentsInput = tl.getInput("arguments", false);
    var enableTls = tl.getBoolInput("enableTls", false);
    if (namespace) {
        helmCli.addArgument("--namespace ".concat(namespace));
    }
    if (enableTls) {
        tlssetting_1.addHelmTlsSettings(helmCli);
    }
    if (argumentsInput) {
        helmCli.addArgument(argumentsInput);
    }
}
exports.addArguments = addArguments;
