"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", { value: true });
const tl = require("azure-pipelines-task-lib/task");
const path = require("path");
const commonCommandOptions = require("./commoncommandoption");
const helmutil = require("./utils");
const restutilities_1 = require("utility-common-v2/restutilities");
const image_metadata_helper_1 = require("kubernetes-common-v2/image-metadata-helper");
const helmcli_1 = require("./helmcli");
const kubernetescli_1 = require("./kubernetescli");
const fs = require("fs");
tl.setResourcePath(path.join(__dirname, '..', 'task.json'));
tl.setResourcePath(path.join(__dirname, '../node_modules/azure-arm-rest-v2/module.json'));
function getKubeConfigFilePath() {
    var userdir = helmutil.getTaskTempDir();
    return path.join(userdir, "config");
}
function getClusterType() {
    var connectionType = tl.getInput("connectionType", true);
    var endpoint = tl.getInput("azureSubscriptionEndpoint");
    if (connectionType === "Azure Resource Manager" && endpoint) {
        return require("./clusters/armkubernetescluster");
    }
    return require("./clusters/generickubernetescluster");
}
function isKubConfigSetupRequired(command) {
    var connectionType = tl.getInput("connectionType", true);
    return command !== "package" && connectionType !== "None";
}
function isKubConfigLogoutRequired(command) {
    var connectionType = tl.getInput("connectionType", true);
    return command !== "package" && command !== "login" && connectionType !== "None";
}
// get kubeconfig file path
function getKubeConfigFile() {
    return __awaiter(this, void 0, void 0, function* () {
        return getClusterType().getKubeConfig().then((config) => {
            var configFilePath = getKubeConfigFilePath();
            tl.debug(tl.loc("KubeConfigFilePath", configFilePath));
            fs.writeFileSync(configFilePath, config);
            return configFilePath;
        });
    });
}
function run() {
    return __awaiter(this, void 0, void 0, function* () {
        var command = tl.getInput("command", true).toLowerCase();
        var isKubConfigRequired = isKubConfigSetupRequired(command);
        var kubectlCli;
        if (isKubConfigRequired) {
            var kubeconfigfilePath = command === "logout" ? tl.getVariable("KUBECONFIG") : yield getKubeConfigFile();
            kubectlCli = new kubernetescli_1.default(kubeconfigfilePath);
            kubectlCli.login();
        }
        var helmCli = new helmcli_1.default();
        helmCli.login();
        var connectionType = tl.getInput("connectionType", true);
        var telemetry = {
            connectionType: connectionType,
            command: command,
            jobId: tl.getVariable('SYSTEM_JOBID')
        };
        var failOnStderr = tl.getBoolInput("failOnStderr");
        console.log("##vso[telemetry.publish area=%s;feature=%s]%s", "TaskEndpointId", "HelmDeployV0", JSON.stringify(telemetry));
        try {
            switch (command) {
                case "login":
                    kubectlCli.setKubeConfigEnvVariable();
                    break;
                case "logout":
                    kubectlCli.unsetKubeConfigEnvVariable();
                    break;
                default:
                    runHelm(helmCli, command, kubectlCli, failOnStderr);
            }
        }
        catch (err) {
            // not throw error so that we can logout from helm and kubernetes
            tl.setResult(tl.TaskResult.Failed, err.message);
        }
        finally {
            if (isKubConfigLogoutRequired(command)) {
                kubectlCli.logout();
            }
            helmCli.logout();
        }
    });
}
function runHelm(helmCli, command, kubectlCli, failOnStderr) {
    var helmCommandMap = {
        "init": "./helmcommands/helminit",
        "install": "./helmcommands/helminstall",
        "package": "./helmcommands/helmpackage",
        "upgrade": "./helmcommands/helmupgrade"
    };
    var commandImplementation = require("./helmcommands/uinotimplementedcommands");
    if (command in helmCommandMap) {
        commandImplementation = require(helmCommandMap[command]);
    }
    //set command
    helmCli.setCommand(command);
    // add arguments
    commonCommandOptions.addArguments(helmCli);
    commandImplementation.addArguments(helmCli);
    const execResult = helmCli.execHelmCommand();
    tl.setVariable('helmExitCode', execResult.code.toString());
    if (execResult.stdout) {
        tl.setVariable('helmOutput', execResult.stdout);
    }
    if (execResult.code != tl.TaskResult.Succeeded || !!execResult.error || (failOnStderr && !!execResult.stderr)) {
        tl.debug('execResult: ' + JSON.stringify(execResult));
        tl.setResult(tl.TaskResult.Failed, execResult.stderr);
    }
    else if ((command === "install" || command === "upgrade")) {
        try {
            let output = execResult.stdout;
            let manifests = image_metadata_helper_1.extractManifestsFromHelmOutput(output);
            if (manifests && manifests.length > 0) {
                const manifestUrls = image_metadata_helper_1.getManifestFileUrlsFromHelmOutput(output);
                manifests.forEach(manifest => {
                    //Check if the manifest object contains a deployment entity
                    if (manifest.kind && image_metadata_helper_1.isDeploymentEntity(manifest.kind)) {
                        try {
                            pushDeploymentDataToEvidenceStore(kubectlCli, manifest, manifestUrls).then((result) => {
                                tl.debug("DeploymentDetailsApiResponse: " + JSON.stringify(result));
                            }, (error) => {
                                tl.warning("publishToImageMetadataStore failed with error: " + error);
                            });
                        }
                        catch (e) {
                            tl.warning("publishToImageMetadataStore failed with error: " + e);
                        }
                    }
                });
            }
        }
        catch (e) {
            tl.warning("Capturing deployment metadata failed with error: " + e);
        }
    }
}
run().then(() => {
    // do nothing
}, (reason) => {
    tl.setResult(tl.TaskResult.Failed, reason);
});
function pushDeploymentDataToEvidenceStore(kubectlCli, deploymentObject, manifestUrls) {
    return __awaiter(this, void 0, void 0, function* () {
        const allPods = JSON.parse(kubectlCli.getAllPods().stdout);
        const clusterInfo = kubectlCli.getClusterInfo().stdout;
        const metadata = image_metadata_helper_1.getDeploymentMetadata(deploymentObject, allPods, "None", clusterInfo, manifestUrls);
        const requestUrl = image_metadata_helper_1.getPublishDeploymentRequestUrl();
        const request = new restutilities_1.WebRequest();
        const accessToken = tl.getEndpointAuthorizationParameter('SYSTEMVSSCONNECTION', 'ACCESSTOKEN', false);
        request.uri = requestUrl;
        request.method = 'POST';
        request.body = JSON.stringify(metadata);
        request.headers = {
            "Content-Type": "application/json",
            "Authorization": "Bearer " + accessToken
        };
        tl.debug("requestUrl: " + requestUrl);
        tl.debug("requestBody: " + JSON.stringify(metadata));
        try {
            tl.debug("Sending request for pushing deployment data to Image meta data store");
            const response = yield restutilities_1.sendRequest(request);
            return response;
        }
        catch (error) {
            tl.debug("Unable to push to deployment details to Artifact Store, Error: " + error);
        }
        return Promise.resolve();
    });
}
